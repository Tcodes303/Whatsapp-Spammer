document.getElementById('startSpam').addEventListener('click', async () => {
  const message = document.getElementById('message').value;
  const count = parseInt(document.getElementById('count').value, 10);

  if (!message || isNaN(count) || count < 1 || count > 100) {
    alert('Please enter a valid message and count (1-100)');
    return;
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: startSpamming,
    args: [message, count],
  });
});

function startSpamming(message, count) {
  let dataTransfer = new DataTransfer();
  let box = document.querySelectorAll("[role=textbox]")[1];
  if (!box) {
    alert("No chat open, Make sure you have opened the chat you want to spam.");
    throw new Error("No chat open, Make sure you have opened the chat you want to spam.");
  }

  dataTransfer.setData("text/plain", message);

  (async () => {
    for (let i = 0; i < count; i++) {
      box.focus();
      box.dispatchEvent(
        new ClipboardEvent("paste", {
          clipboardData: dataTransfer,
          bubbles: true,
          cancelable: true,
        })
      );

      await new Promise((resolve) => setTimeout(resolve, 1000));

      box.parentElement.parentElement.parentElement.children[1].children[0].click();
      console.log(`"${message}" sent -> ${i + 1} times`);
    }
  })();
}